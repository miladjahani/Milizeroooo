// لایهٔ Cloudflare API — همهٔ درخواست‌ها با توکن کاربر و بدون ذخیره‌سازی.
// نکتهٔ کلیدی: برای جلوگیری از خطای 1101 همیشه قبل از آپلود، اسکریپت قبلی
// حذف می‌شود و بعد نسخهٔ جدید یکجا (metadata + ماژول‌ها) فرستاده می‌شود.

const API = 'https://api.cloudflare.com/client/v4';

export class CfError extends Error {
  constructor(message, { status = 0, code = 0, errors = [] } = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.errors = errors;
  }
}

const ERROR_HINTS = {
  10000: 'توکن API نامعتبر است یا منقضی شده',
  10001: 'درخواست نامعتبر است',
  10007: 'توکن به این حساب دسترسی ندارد',
  10013: 'سهمیهٔ حساب تمام شده است',
  10021: 'آپلود رد شد؛ متن خطای کلادفلر را ببین (کد ۱۰۰۲۱)',
  8000009: 'پروژه از قبل وجود دارد',
  1101: 'استقرار ناسالم شد (1101)؛ حذف و آپلود مجدد لازم است',
  10063: 'توکن اجازهٔ Workers Scripts را ندارد',
  10064: 'توکن اجازهٔ Pages را ندارد'
};

function humanError(status, body) {
  const errors = Array.isArray(body?.errors) ? body.errors : [];
  const first = errors[0] || {};
  const code = Number(first.code || 0);
  const base = ERROR_HINTS[code] || first.message || body?.message || 'خطای نامشخص از کلادفلر';
  const extra = first.message && ERROR_HINTS[code] ? ' (' + first.message + ')' : '';
  return new CfError(base + extra, { status, code, errors });
}

export async function cf(token, path, { method = 'GET', body, headers = {} } = {}) {
  if (!token) throw new CfError('توکن API کلادفلر را وارد کن', { status: 401 });
  const isBinary = body instanceof Uint8Array || body instanceof ArrayBuffer || body instanceof Blob;
  const isMultipart = body instanceof FormData || isBinary;
  const init = {
    method,
    headers: {
      Authorization: 'Bearer ' + token,
      ...(body && !isMultipart ? { 'Content-Type': 'application/json' } : {}),
      ...headers
    }
  };
  if (body) {
    init.body = (isMultipart || typeof body === 'string') ? body : JSON.stringify(body);
  }

  const res = await fetch(API + path, init);
  let data = null;
  const raw = await res.text();
  if (raw) { try { data = JSON.parse(raw); } catch (_e) { data = { raw }; } }
  if (!res.ok || data?.success === false) throw humanError(res.status, data);
  return data;
}

export async function listAccounts(token) {
  const data = await cf(token, '/accounts?per_page=50');
  return (data.result || []).map(a => ({ id: a.id, name: a.name }));
}

// ── multipart سازگار با Workers (بدون FormData برای فایل‌های باینری) ────────
function buildMultipart(parts) {
  const boundary = '----cfdeployer' + (crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '') : Date.now());
  const enc = new TextEncoder();
  const chunks = [];
  for (const part of parts) {
    chunks.push(enc.encode('--' + boundary + '\r\n'));
    let disposition = 'Content-Disposition: form-data; name="' + part.name + '"';
    if (part.filename) disposition += '; filename="' + part.filename + '"';
    chunks.push(enc.encode(disposition + '\r\n'));
    if (part.contentType) chunks.push(enc.encode('Content-Type: ' + part.contentType + '\r\n'));
    chunks.push(enc.encode('\r\n'));
    chunks.push(typeof part.data === 'string' ? enc.encode(part.data) : part.data);
    chunks.push(enc.encode('\r\n'));
  }
  chunks.push(enc.encode('--' + boundary + '--\r\n'));
  const total = chunks.reduce((sum, c) => sum + c.length, 0);
  const body = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { body.set(chunk, offset); offset += chunk.length; }
  return { body, contentType: 'multipart/form-data; boundary=' + boundary };
}

const baseName = (p) => String(p).split('/').pop();

// ── Workers ────────────────────────────────────────────────────────────────
export async function scriptExists(token, accountId, name) {
  try {
    await cf(token, `/accounts/${accountId}/workers/scripts/${encodeURIComponent(name)}`);
    return true;
  } catch (err) {
    if (err.status === 404) return false;
    throw err;
  }
}

export async function deleteScript(token, accountId, name) {
  try {
    await cf(token, `/accounts/${accountId}/workers/scripts/${encodeURIComponent(name)}`, { method: 'DELETE' });
    return true;
  } catch (err) {
    if (err.status === 404) return false;
    throw err;
  }
}

export async function uploadWorkerScript({ token, accountId, name, files, mainFile, bindings, compatibilityDate, classic }) {
  const modules = new Map();
  const exactMain = files.find(f => f.path === mainFile) || files.find(f => baseName(f.path) === baseName(mainFile || '')) || files[0];
  const mainText = exactMain ? new TextDecoder().decode(exactMain.data.subarray(0, 8192)) : '';
  const isSelfContainedBundle = !(/from\s+['"]\.\.\//m.test(mainText) || /from\s+['"]\.\//m.test(mainText));
  if (exactMain && isSelfContainedBundle) {
    modules.set(baseName(exactMain.path), exactMain);
  } else {
    for (const file of files) {
      if (!/\.(m?js|cjs)$/i.test(file.path)) continue;
      const moduleName = baseName(file.path);
      if (!modules.has(moduleName)) modules.set(moduleName, file);
    }
  }
  const mainName = classic ? '' : baseName((exactMain && exactMain.path) || mainFile || files[0].path);
  if (!classic && !modules.has(mainName)) {
    throw new CfError('فایل ورودی «' + mainName + '» بین ماژول‌ها پیدا نشد');
  }

  const metadata = {
    compatibility_date: compatibilityDate || '2024-11-06',
    bindings: (bindings || []).filter(b => b && b.name && (b.type === 'plain_text' || b.id || b.namespace_id))
  };
  if (!classic) metadata.main_module = mainName;

  const parts = [{ name: 'metadata', data: JSON.stringify(metadata), contentType: 'application/json' }];
  for (const [moduleName, file] of modules) {
    parts.push({
      name: moduleName,
      filename: moduleName,
      contentType: classic ? 'application/javascript' : 'application/javascript+module',
      data: file.data
    });
  }
  const { body, contentType } = buildMultipart(parts);
  await cf(token, `/accounts/${accountId}/workers/scripts/${encodeURIComponent(name)}`, {
    method: 'PUT',
    body,
    headers: { 'Content-Type': contentType }
  });
  return { mainModule: classic ? null : mainName, moduleCount: modules.size };
}

export async function enableWorkersDev(token, accountId, name) {
  await cf(token, `/accounts/${accountId}/workers/scripts/${encodeURIComponent(name)}/subdomain`, {
    method: 'POST',
    body: { enabled: true, previews_enabled: false }
  });
}

export async function getSubdomain(token, accountId) {
  try {
    const data = await cf(token, `/accounts/${accountId}/workers/subdomain`);
    return data?.result?.subdomain || '';
  } catch (_e) {
    return '';
  }
}

// ── KV (فضای نام) ──────────────────────────────────────────────────────────
export async function listKvNamespaces(token, accountId) {
  const data = await cf(token, `/accounts/${accountId}/storage/kv/namespaces?per_page=100`);
  return (data.result || []).map(ns => ({ id: ns.id, title: ns.title }));
}

export async function createKvNamespace(token, accountId, title) {
  const data = await cf(token, `/accounts/${accountId}/storage/kv/namespaces`, {
    method: 'POST',
    body: { title }
  });
  return data.result;
}

// ── D1 ─────────────────────────────────────────────────────────────────────
export async function createD1(token, accountId, name) {
  const data = await cf(token, `/accounts/${accountId}/d1/database`, { method: 'POST', body: { name } });
  return data.result;
}

export async function runD1Schema(token, accountId, databaseId, sql) {
  const statements = String(sql || '')
    .split(';')
    .map(s => s.trim())
    .filter(Boolean);
  const results = [];
  for (const statement of statements) {
    const data = await cf(token, `/accounts/${accountId}/d1/database/${databaseId}/query`, {
      method: 'POST',
      body: { sql: statement }
    });
    results.push(data.result);
  }
  return results.length;
}

// ── Pages ──────────────────────────────────────────────────────────────────
export async function ensurePagesProject(token, accountId, name) {
  try {
    const data = await cf(token, `/accounts/${accountId}/pages/projects/${encodeURIComponent(name)}`);
    return { created: false, project: data.result };
  } catch (err) {
    if (err.status !== 404 && err.code !== 8000009) throw err;
  }
  try {
    const data = await cf(token, `/accounts/${accountId}/pages/projects`, {
      method: 'POST',
      body: { name, production_branch: 'main' }
    });
    return { created: true, project: data.result };
  } catch (err) {
    if (err.code === 8000009) return { created: false, project: null };
    throw err;
  }
}

async function sha256Base64(bytes) {
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  let binary = '';
  const view = new Uint8Array(digest);
  for (let i = 0; i < view.length; i++) binary += String.fromCharCode(view[i]);
  return btoa(binary);
}

const MIME = {
  html: 'text/html; charset=utf-8',
  js: 'application/javascript; charset=utf-8',
  mjs: 'application/javascript; charset=utf-8',
  css: 'text/css; charset=utf-8',
  json: 'application/json; charset=utf-8',
  svg: 'image/svg+xml',
  txt: 'text/plain; charset=utf-8',
  ico: 'image/x-icon',
  png: 'image/png',
  webmanifest: 'application/manifest+json'
};

export async function deployPagesProject({ token, accountId, name, files }) {
  const manifest = {};
  const parts = [];
  for (const file of files) {
    if (/^_worker\.js$/i.test(file.path)) continue; // جداگانه فرستاده می‌شود
    const route = '/' + file.path.replace(/^\/+/, '');
    const hash = await sha256Base64(file.data);
    manifest[route] = hash;
    const ext = (file.path.split('.').pop() || '').toLowerCase();
    parts.push({ name: hash, filename: hash, contentType: MIME[ext] || 'application/octet-stream', data: file.data });
  }
  const worker = files.find(f => /^_worker\.js$/i.test(f.path));
  if (worker) {
    const hash = await sha256Base64(worker.data);
    manifest['/_worker.js'] = hash;
    parts.push({ name: hash, filename: hash, contentType: 'application/javascript', data: worker.data });
  }
  if (!parts.length) throw new CfError('هیچ فایلی برای آپلود روی Pages وجود ندارد');

  const { body, contentType } = buildMultipart([
    { name: 'manifest', data: JSON.stringify(manifest), contentType: 'application/json' },
    ...parts
  ]);
  const data = await cf(token, `/accounts/${accountId}/pages/projects/${encodeURIComponent(name)}/deployments`, {
    method: 'POST',
    body,
    headers: { 'Content-Type': contentType }
  });
  return {
    url: data?.result?.url || '',
    uploads: parts.length
  };
}

// ── تست سلامت و تشخیص 1101 ─────────────────────────────────────────────────
export async function healthCheck(url, { retries = 3, delayMs = 5000, sleep = defaultSleep } = {}) {
  const attempts = [];
  for (let i = 0; i < retries; i++) {
    if (i > 0) await sleep(delayMs);
    try {
      const res = await fetch(url, { redirect: 'follow', headers: { 'User-Agent': 'cf-deployer/1.0' } });
      const body = (await res.text()).slice(0, 4000);
      // صفحهٔ خطای ۱۱۰۱ کلادفلر می‌تواند «error code: 1101»، «Error 1101» یا
      // «Worker threw a runtime exception» باشد؛ هر سه ناسالم حساب می‌شوند.
      const bad1101 = /error\s*(code)?\s*[:#]?\s*1101/i.test(body) ||
        /worker threw (a )?(runtime )?exception/i.test(body);
      attempts.push({ status: res.status, bad1101 });
      // ۴۰۴ روی workers.dev معمولاً یعنی انتشار هنوز تمام نشده؛ صبر و تلاش دوباره
      if (res.status !== 404 && res.status < 500 && !bad1101) {
        return { ok: true, status: res.status, attempts };
      }
      if (bad1101) return { ok: false, status: 1101, reason: '1101', attempts };
    } catch (err) {
      attempts.push({ status: 0, error: String(err?.message || err) });
    }
  }
  const last = attempts[attempts.length - 1] || {};
  return { ok: false, status: last.status || 0, reason: last.bad1101 ? '1101' : 'unreachable', attempts };
}

export function defaultSleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// متادیتای bindingها را برای ارسال به API آماده می‌کند
export function normalizeBindings(list = []) {
  return list.map(item => {
    if (!item || !item.name) return null;
    if (item.type === 'd1') return { type: 'd1', name: item.name, id: item.id };
    if (item.type === 'kv_namespace') return { type: 'kv_namespace', name: item.name, namespace_id: item.namespace_id || item.id };
    if (item.type === 'r2_bucket') return { type: 'r2_bucket', name: item.name, bucket_name: item.bucket_name || item.id };
    if (item.type === 'plain_text') return { type: 'plain_text', name: item.name, text: String(item.text ?? '') };
    return null;
  }).filter(Boolean);
}
