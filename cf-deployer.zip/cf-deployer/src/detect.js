// تشخیص خودکار نوع پروژه از روی فایل‌های آپلودشده.
// هیچ حدس بی‌صدایی زده نمی‌شود: هر تشخیص همراه هشدارهایش به کلاینت برمی‌گردد.

const MAX_FILE_BYTES = 10 * 1024 * 1024;
const SKIP_DIRS = ['node_modules/', '.git/', '.github/', '.wrangler/', 'dist/assets/', 'scripts/'];

const text = (files, path) => {
  const f = files.find(x => x.path === path);
  return f ? new TextDecoder().decode(f.data) : '';
};

const basename = (p) => p.split('/').pop();

// TOML سبک: فقط کلیدهای موردنیاز wrangler خوانده می‌شود
export function parseWranglerToml(source = '') {
  const out = { main: '', name: '', compatibilityDate: '', bindings: [], d1: [], kv: [], r2: [] };
  const lines = String(source).split(/\r?\n/);
  let table = '';
  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const header = line.match(/^\[\[?([^\]]+)\]\]?$/);
    if (header) { table = header[1].trim(); continue; }
    const kv = line.match(/^([A-Za-z0-9_.-]+)\s*=\s*"([^"]*)"/);
    if (!kv) continue;
    const [, key, value] = kv;
    if (!table) {
      if (key === 'main') out.main = value;
      else if (key === 'name') out.name = value;
      else if (key === 'compatibility_date') out.compatibilityDate = value;
      continue;
    }
    if (table === 'd1_databases' && key === 'binding') out.d1.push({ name: value, id: '' });
    if (table === 'd1_databases' && key === 'database_id') {
      if (out.d1.length) out.d1[out.d1.length - 1].id = value;
    }
    if (table === 'kv_namespaces' && key === 'binding') out.kv.push({ name: value, id: '' });
    if (table === 'kv_namespaces' && key === 'id') {
      if (out.kv.length) out.kv[out.kv.length - 1].id = value;
    }
    if (table === 'r2_buckets' && key === 'binding') out.r2.push(value);
  }
  return out;
}

function usableFiles(files) {
  return files
    .filter(f => f && f.path && !SKIP_DIRS.some(dir => f.path.startsWith(dir)))
    .filter(f => !f.path.split('/').includes('..'))
    .filter(f => f.data.length <= MAX_FILE_BYTES);
}

function looksLikeWorkerModule(src) {
  return /export\s+default\s*(\{|[A-Za-z_$])/.test(src) && /fetch\s*\(/.test(src);
}
function looksLikeServiceWorker(src) {
  return /addEventListener\(\s*['"]fetch['"]/.test(src);
}

// ورودی: [{path, data}] — خروجی: تشخیص کامل + هشدارها
export function detectProject(inputFiles, hints = {}) {
  const files = usableFiles(inputFiles || []);
  const warnings = [];
  if (!files.length) throw new Error('هیچ فایل قابل استقراری در منبع پیدا نشد');

  const jsFiles = files.filter(f => /\.(m?js|cjs)$/i.test(f.path));
  const tomlFile = files.find(f => /^wrangler\.(toml|jsonc?)$/i.test(f.path));
  const packageFile = files.find(f => f.path === 'package.json');
  const pagesWorker = files.find(f => f.path === '_worker.js' || f.path === 'functions/_worker.js');
  const hasIndexHtml = files.some(f => f.path === 'index.html');
  const hasDist = files.some(f => f.path.startsWith('dist/') && f.path.endsWith('.html'));

  let mode = 'worker';
  let mainFile = '';
  let kind = 'worker-module';
  let name = hints.name || '';
  let compatibilityDate = '';
  let bindings = [];
  let staticFiles = [];

  if (tomlFile) {
    const toml = parseWranglerToml(new TextDecoder().decode(tomlFile.data));
    name = name || toml.name || '';
    compatibilityDate = toml.compatibilityDate || '';
    if (toml.main && files.some(f => f.path === toml.main)) mainFile = toml.main;
    bindings = [
      ...toml.d1.map(d => ({ type: 'd1', name: d.name, id: d.id })),
      ...toml.kv.map(k => ({ type: 'kv_namespace', name: k.name, namespace_id: k.id })),
      ...toml.r2.map(r => ({ type: 'r2_bucket', name: r }))
    ];
    for (const b of bindings) {
      if (!b.id) warnings.push('binding «' + b.name + '» در wrangler.toml شناسه ندارد و باید در تنظیمات پر شود');
    }
  }

  if (pagesWorker && !mainFile) {
    mode = 'worker';
    kind = 'worker-module';
    mainFile = pagesWorker.path;
    staticFiles = files.filter(f => f !== pagesWorker);
  } else if (pagesWorker && mainFile === pagesWorker.path) {
    mode = 'worker';
    kind = 'worker-module';
    staticFiles = files.filter(f => f !== pagesWorker);
  } else if (!mainFile && hasDist) {
    mode = 'pages';
    kind = 'pages-static';
    staticFiles = files.filter(f => f.path.startsWith('dist/')).map(f => ({ ...f, path: f.path.slice(5) }));
    mainFile = '';
  } else if (!mainFile && hasIndexHtml) {
    mode = 'pages';
    kind = 'pages-static';
    staticFiles = files.filter(f => !f.path.startsWith('node_modules/'));
    mainFile = '';
  } else if (!mainFile) {
    // بزرگ‌ترین فایل JS که شبیه ورکر است
    const candidates = jsFiles
      .map(f => ({ file: f, src: new TextDecoder().decode(f.data.subarray(0, 4000)) }))
      .filter(x => looksLikeWorkerModule(x.src) || looksLikeServiceWorker(x.src))
      .sort((a, b) => b.file.data.length - a.file.data.length);
    if (candidates.length) {
      mainFile = candidates[0].file.path;
      kind = looksLikeServiceWorker(candidates[0].src) ? 'worker-classic' : 'worker-module';
      if (candidates.length > 1) {
        warnings.push('چند فایل شبیه ورکر پیدا شد؛ «' + mainFile + '» انتخاب شد. اگر اشتباه است در تنظیمات عوضش کن.');
      }
    } else if (jsFiles.length) {
      mainFile = jsFiles.sort((a, b) => b.data.length - a.data.length)[0].path;
      kind = 'worker-module';
      warnings.push('هیچ فایل ورکر مشخصی پیدا نشد؛ بزرگ‌ترین فایل JS به‌عنوان ورودی انتخاب شد');
    } else {
      throw new Error('فایل ورکر یا index.html پیدا نشد');
    }
  }

  if (packageFile) {
    try {
      const pkg = JSON.parse(new TextDecoder().decode(packageFile.data));
      name = hints.name || name || pkg.name || '';
      if (!compatibilityDate && pkg.cloudflare && pkg.cloudflare.compatibility_date) {
        compatibilityDate = pkg.cloudflare.compatibility_date;
      }
    } catch (_e) { /* package.json خراب مهم نیست */ }
  }

  name = String(hints.name || name || 'my-panel')
    .toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 54) || 'my-panel';

  const totalBytes = files.reduce((sum, f) => sum + f.data.length, 0);
  if (totalBytes > 10 * 1024 * 1024) warnings.push('حجم پروژه بیشتر از ۱۰ مگابایت است؛ ممکن است آپلود رد شود');
  if (mode === 'pages' && kind === 'pages-static') {
    warnings.push('پروژهٔ استاتیک است: فایل‌ها مستقیم روی Pages آپلود می‌شوند (بدون build)');
  }
  if (kind === 'worker-classic') {
    warnings.push('ورکر کلاسیک (addEventListener) شناسایی شد؛ بدون main_module استقرار داده می‌شود');
  }

  return {
    mode,
    kind,
    name,
    mainFile,
    compatibilityDate: compatibilityDate || '2024-11-06',
    bindings,
    warnings,
    sizeBytes: totalBytes,
    fileCount: files.length,
    files: mode === 'pages' ? staticFiles : files
  };
}
